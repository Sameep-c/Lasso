/*
This project has been made by Sameep Chatopadhyay, 20D070067 for CS101.
Most of the rules of game and the controls have been well  explained in the function help_page() defined around line 235.
Enhancements made by me are:
1) Creating multiple levels in the game.
2) Creation of a bomb.
3) Creation of parabolically moving coin.
4) Making the game much more interactive using pop up messages.
5) Creating concept of lives(in form of level score), you lose if your level score is negative.
6) Designed help page for the players.
Overall additional code written is more than 400 lines(including comments & blank lines)*/

#include <simplecpp>
#include <string>
#include <vector>
#include <stdio.h>
#include <stdlib.h>
#include<fstream>
using namespace simplecpp;

//movingObject.h
#ifndef _MOVINGOBJECT_INCLUDED_
#define _MOVINGOBJECT_INCLUDED_

#include <simplecpp>
#include <vector>
#include <composite.h>
#include <sprite.h>

using namespace simplecpp;

class MovingObject : public Sprite {
  vector<Sprite*> parts;
  double vx, vy;
  double ax, ay;
  bool paused;
  void initMO(double argvx, double argvy, double argax, double argay, bool argpaused=true) {
    vx=argvx; vy=argvy; ax=argax; ay=argay; paused=argpaused;
  }
 public:
 MovingObject(double argvx, double argvy, double argax, double argay, bool argpaused=true)
    : Sprite() {
    initMO(argvx, argvy, argax, argay, argpaused);
  }
 MovingObject(double speed, double angle_deg, double argax, double argay, bool argpaused, bool rtheta) : Sprite() {
   double angle_rad = angle_deg*PI/180.0;
   double argvx = speed*cos(angle_rad);
   double argvy = -speed*sin(angle_rad);
   initMO(argvx, argvy, argax, argay, argpaused);
  }
  void set_vx(double argvx) { vx = argvx; }
  void set_vy(double argvy) { vy = argvy; }
  void set_ax(double argax) { ax = argax; }
  void set_ay(double argay) { ay = argay; }
  double getXPos();
  double getYPos();
  void reset_all(double argx, double argy, double speed, double angle_deg, double argax, double argay, bool argpaused, bool rtheta);

  void pause() { paused = true; }
  void unpause() { paused = false; }
  bool isPaused() { return paused; }

  void addPart(Sprite* p) {
    parts.push_back(p);
  }
  void nextStep(double t);
  void getAttachedTo(MovingObject *m);
};

#endif

//MovingObject.cpp

void MovingObject::nextStep(double t) {
  if(paused) { return; }
  //cerr << "x=" << getXPos() << ",y=" << getYPos() << endl;
  //cerr << "vx=" << vx << ",vy=" << vy << endl;
  //cerr << "ax=" << ax << ",ay=" << ay << endl;

  for(size_t i=0; i<parts.size(); i++){
    parts[i]->move(vx*t, vy*t);
  }
  vx += ax*t;
  vy += ay*t;
} // End MovingObject::nextStep()

double MovingObject::getXPos() {
  return (parts.size() > 0) ? parts[0]->getX() : -1;
}

double MovingObject::getYPos() {
  return (parts.size() > 0) ? parts[0]->getY() : -1;
}

void MovingObject::reset_all(double argx, double argy, double speed, double angle_deg, double argax, double argay, bool argpaused, bool rtheta) {
  for(size_t i=0; i<parts.size(); i++){
    parts[i]->moveTo(argx, argy);
  }
  double angle_rad = angle_deg*PI/180.0;
  double argvx = speed*cos(angle_rad);
  double argvy = -speed*sin(angle_rad);
  vx = argvx; vy = argvy; ax = argax; ay = argay; paused = argpaused;
} // End MovingObject::reset_all()

void MovingObject::getAttachedTo(MovingObject *m) {
  double xpos = m->getXPos();
  double ypos = m->getYPos();
  for(size_t i=0; i<parts.size(); i++){
    parts[i]->moveTo(xpos, ypos);
  }
  initMO(m->vx, m->vy, m->ax, m->ay, m->paused);
}

//coin.h
#ifndef __COIN_H__
#define __COIN_H__

class Bomb : public MovingObject {
  double bomb_start_x;
  double bomb_start_y;
  double release_speed;
  double release_angle_deg;
  double bomb_ax;
  double bomb_ay;
  //double coin_step;

  // Moving parts
  Circle bomb_circle;

 public:
 Bomb(double speed, double angle_deg, double argax, double argay, bool argpaused, bool rtheta) : MovingObject(speed, angle_deg, argax, argay, argpaused, rtheta) {
    release_speed = speed;
    release_angle_deg = angle_deg;
    bomb_ax = argax;
    bomb_ay = argay;
    initBomb();
  }

  void initBomb();
  void resetBomb();};

class Coin : public MovingObject {
  double coin_start_x;
  double coin_start_y;
  double release_speed;
  double release_angle_deg;
  double coin_ax;
  double coin_ay;
  double coin_step;

  // Moving parts
  Circle coin_circle;

 public:
 Coin(double speed, double angle_deg, double argax, double argay, bool argpaused, bool rtheta) : MovingObject(speed, angle_deg, argax, argay, argpaused, rtheta) {
    release_speed = speed;
    release_angle_deg = angle_deg;
    coin_ax = argax;
    coin_ay = argay;
    initCoin();
  }

  void initCoin();
  void resetCoin();
   public:
  int Coinstep(){return coin_step;}

}; // End class Coin
class BCoin : public MovingObject {
  double bcoin_start_x;
  double bcoin_start_y;
  double release_speed;
  double release_angle_deg;
  double bcoin_ax;
  double bcoin_ay;
  double bcoin_step;

  // Moving parts
  Circle bcoin_circle;

 public:
 BCoin(double speed, double angle_deg, double argax, double argay, bool argpaused, bool rtheta) : MovingObject(speed, angle_deg, argax, argay, argpaused, rtheta) {
    release_speed = speed;
    release_angle_deg = angle_deg;
    bcoin_ax = argax;
    bcoin_ay = argay;
    initBCoin();
  }

  void initBCoin();
  void resetBCoin();
   public:
};
#endif

//lasso.h
#ifndef __LASSO_H__
#define __LASSO_H__

//#define WINDOW_X 1200
//#define WINDOW_Y 960
#define WINDOW_X 800
#define WINDOW_Y 600

#define STEP_TIME 0.05

#define PLAY_X_START 100
#define PLAY_Y_START 0
#define PLAY_X_WIDTH (WINDOW_X-PLAY_X_START)
#define PLAY_Y_HEIGHT (WINDOW_Y-100)

#define LASSO_X_OFFSET 100
#define LASSO_Y_HEIGHT 100
#define LASSO_BAND_LENGTH LASSO_X_OFFSET
#define LASSO_THICKNESS 5

#define COIN_GAP 1

#define RELEASE_ANGLE_STEP_DEG 5
#define MIN_RELEASE_ANGLE_DEG 0
#define MAX_RELEASE_ANGLE_DEG (360-RELEASE_ANGLE_STEP_DEG)
#define INIT_RELEASE_ANGLE_DEG 45

#define RELEASE_SPEED_STEP 20
#define MIN_RELEASE_SPEED 0
#define MAX_RELEASE_SPEED 200
#define INIT_RELEASE_SPEED 100

#define COIN_SPEED 120
#define COIN_ANGLE_DEG 90

#define LASSO_G 30
#define COIN_G 30

#define LASSO_SIZE 10
#define LASSO_RADIUS 50
#define COIN_SIZE 5

void help_page(){
bool check = true;
  while(check==true){
   string messeg1("WELCOME PLAYER !!");
   Text charPressed1(PLAY_X_START+300, PLAY_Y_HEIGHT-450, messeg1);charPressed1.setColor(COLOR("blue"));
   string messeg2("CONTROLS:");
   Text charPressed2(PLAY_X_START+300, PLAY_Y_HEIGHT-400, messeg2);
   string messeg3("1)  PRESS 't' TO THROW LASSO                       ");
   Text charPressed3(PLAY_X_START+300, PLAY_Y_HEIGHT-360, messeg3);
   string messeg4("2)  PRESS 'y' TO YANK LASSO TO INITIAL POSITION");
   Text charPressed4(PLAY_X_START+300, PLAY_Y_HEIGHT-320, messeg4);
   string messeg5("3)  PRESS 'l' TO LOOP COIN TO LASSO              ");
   Text charPressed5(PLAY_X_START+300, PLAY_Y_HEIGHT-280, messeg5);
   string messeg6("    IF COIN IS NEARBY IT GETS CAUGHT             ");
   Text charPressed6(PLAY_X_START+300, PLAY_Y_HEIGHT-240, messeg6);
   string messeg7("4)  PRESS 'q' TO QUIT THE GAME                     ");
   Text charPressed7(PLAY_X_START+300, PLAY_Y_HEIGHT-200, messeg7);
wait(10);
check=false;}
check = true;
  while(check==true){
   string messeg1("WELCOME PLAYER !!");
   Text charPressed1(PLAY_X_START+300, PLAY_Y_HEIGHT-450, messeg1);charPressed1.setColor(COLOR("blue"));
   string messeg2("CONTROLS:");
   Text charPressed2(PLAY_X_START+300, PLAY_Y_HEIGHT-400, messeg2);
   string messeg3("5)  PRESS '[' TO DECREASE THE ANGLE AT WHICH LASSO IS LAUNCHED ");
   Text charPressed3(PLAY_X_START+300, PLAY_Y_HEIGHT-360, messeg3);
   string messeg4("6)  PRESS ']' TO INCREASE THE ANGLE AT WHICH LASSO IS LAUNCHED");
   Text charPressed4(PLAY_X_START+300, PLAY_Y_HEIGHT-320, messeg4);
   string messeg5("7)  PRESS '=' TO INCREASE THE SPEED AT WHICH LASSO IS LAUNCHED");
   Text charPressed5(PLAY_X_START+300, PLAY_Y_HEIGHT-280, messeg5);
   string messeg6("8)  PRESS '[' TO DECREASE THE SPEED AT WHICH LASSO IS LAUNCHED ")
   ;Text charPressed6(PLAY_X_START+300, PLAY_Y_HEIGHT-240, messeg6);
  // string messeg7("4)  PRESS 'q' TO QUIT THE GAME                     ");Text charPressed7(PLAY_X_START+300, PLAY_Y_HEIGHT-200, messeg7);
wait(10);check=false;}
check = true;
 while(check==true){
   string messeg1("WELCOME PLAYER !!");
   Text charPressed1(PLAY_X_START+300, PLAY_Y_HEIGHT-450, messeg1);charPressed1.setColor(COLOR("blue"));
   string messeg2("RULES:");
   Text charPressed2(PLAY_X_START+300, PLAY_Y_HEIGHT-400, messeg2);
   string messeg3("THE GAME HAS THREE LEVELS WITH 5 ATTEMPTS          ");
   Text charPressed3(PLAY_X_START+300, PLAY_Y_HEIGHT-360, messeg3);
   string messeg4("YOU HAVE TO GET A SCORE MORE THAN 2 IN A LEVEL TO PASS ");
   Text charPressed4(PLAY_X_START+300, PLAY_Y_HEIGHT-320, messeg4);
   string messeg5("IF YOU PASS, YOU MOVE TO THE NEXT LEVEL            ");
   Text charPressed5(PLAY_X_START+300, PLAY_Y_HEIGHT-280, messeg5);
   string messeg6("IF YOU FAIL, YOU HAVE TO REPEAT THE LEVEL            ");
   Text charPressed6(PLAY_X_START+300, PLAY_Y_HEIGHT-240, messeg6);
   string messeg7("IF YOUR SCORE IS NEGATIVE, YOU LOSE THE GAME          ");
   Text charPressed7(PLAY_X_START+300, PLAY_Y_HEIGHT-200, messeg7);
wait(10);
check=false;}
check = true;
while(check==true){
   string messeg1("WELCOME PLAYER !!");
   Text charPressed1(PLAY_X_START+300, PLAY_Y_HEIGHT-450, messeg1);charPressed1.setColor(COLOR("blue"));
   string messeg2("RULES:");
   Text charPressed2(PLAY_X_START+300, PLAY_Y_HEIGHT-400, messeg2);
   string messeg3("LEVEL ONE HAS 1 COIN WHICH HAS TO BE CAUGHT  ");
   Text charPressed3(PLAY_X_START+300, PLAY_Y_HEIGHT-360, messeg3);
   string messeg4("CATCHING THE COIN INCREASES YOUR SCORE  ");
   Text charPressed4(PLAY_X_START+300, PLAY_Y_HEIGHT-320, messeg4);
   string messeg5(" LEVEL TWO HAS A COIN AND A BOMB          ");
   Text charPressed5(PLAY_X_START+300, PLAY_Y_HEIGHT-280, messeg5);
   string messeg6(" CATCHING THE BOMB REDUCES YOUR SCORE       ");
   Text charPressed6(PLAY_X_START+300, PLAY_Y_HEIGHT-240, messeg6);
   string messeg7("LEVEL 3 HAS AN ADDITIONAL BONUS COIN     ");
   Text charPressed7(PLAY_X_START+300, PLAY_Y_HEIGHT-200, messeg7);
   string messeg8("A BONUS COIN HAS WORTH OF TWO COINS      ");
   Text charPressed8(PLAY_X_START+300, PLAY_Y_HEIGHT-160, messeg8);
wait(10);check=false;}
check = true;
 while(check==true){
   string messeg1("WELCOME PLAYER !!");
   Text charPressed1(PLAY_X_START+300, PLAY_Y_HEIGHT-450, messeg1);
   charPressed1.setColor(COLOR("blue"));
   string messeg2("GAME BEGINS IN:  3");
   Text charPressed2(PLAY_X_START+300, PLAY_Y_HEIGHT-300, messeg2);
   charPressed2.setColor(COLOR("red"));
wait(1);
check=false;}
check = true;
 while(check==true){
   string messeg1("WELCOME PLAYER !!");
   Text charPressed1(PLAY_X_START+300, PLAY_Y_HEIGHT-450, messeg1);
   charPressed1.setColor(COLOR("blue"));
   string messeg2("GAME BEGINS IN:  2");
   Text charPressed2(PLAY_X_START+300, PLAY_Y_HEIGHT-300, messeg2);
   charPressed2.setColor(COLOR("red"));
wait(1);
check=false;}
check = true;
 while(check==true){
   string messeg1("WELCOME PLAYER !!");
   Text charPressed1(PLAY_X_START+300, PLAY_Y_HEIGHT-450, messeg1);
   charPressed1.setColor(COLOR("blue"));
   string messeg2("GAME BEGINS IN:  1");Text charPressed2(PLAY_X_START+300, PLAY_Y_HEIGHT-300, messeg2);
   charPressed2.setColor(COLOR("red"));
wait(1);check=false;}
check = true;
while(check==true){
   string messeg1("WELCOME PLAYER !!");
   Text charPressed1(PLAY_X_START+300, PLAY_Y_HEIGHT-450, messeg1);
   charPressed1.setColor(COLOR("blue"));
   string messeg2("ALL THE BEST !!");
   Text charPressed2(PLAY_X_START+300, PLAY_Y_HEIGHT-300, messeg2);
   charPressed2.setColor(COLOR("red"));
wait(1);check=false;}
return;}

class Lasso : public MovingObject {
  double lasso_start_x;
  double lasso_start_y;
  double release_speed;
  double release_angle_deg;
  double lasso_ax;
  double lasso_ay;

  // Moving parts
  Circle lasso_circle;
  Circle lasso_loop;

  // Non-moving parts
  Line lasso_line;
  Line lasso_band;

  // State info
  bool lasso_looped;
  Coin *the_coin;
  Bomb * the_bomb;
  BCoin *the_bcoin;
  int num_coins;
  int coin_count;
 // int coinstepT;
  int coin_step;
  int level;

  void initLasso();
 public:
 Lasso(double speed, double angle_deg, double argax, double argay, bool argpaused, bool rtheta) : MovingObject(speed, angle_deg, argax, argay, argpaused, rtheta) {
    release_speed = speed;
    release_angle_deg = angle_deg;
    lasso_ax = argax;
    lasso_ay = argay;
    initLasso();
  }
void draw_lasso_band();
  void yank();
  void loopit();
  void addAngle(double angle_deg);
  void addSpeed(double speed);

  void nextStep(double t);
  void check_for_coin(Coin *coin);
  void check_for_bcoin(BCoin *coin);
  void check_for_bomb(Bomb *coinPtr);
  int getNumCoins() { return num_coins; }
  int getCoinstep(){return coin_step;}
  int getlevel(){return level;}
  int getlevelscore(){return coin_count;}

}; // End class Lasso

#endif

//coin.h
void Bomb::initBomb() {
  bomb_start_x = ((PLAY_X_START+WINDOW_X)/2)+20;
  bomb_start_y = PLAY_Y_HEIGHT;
  bomb_circle.reset(bomb_start_x, bomb_start_y, COIN_SIZE);
  bomb_circle.setColor(COLOR("black"));
  bomb_circle.setFill(true);
  addPart(&bomb_circle);
}
void Bomb::resetBomb() {
  double coin_speed = COIN_SPEED;
  double coin_angle_deg = COIN_ANGLE_DEG;
  bomb_ax = 0;
  bomb_ay = COIN_G;
  bool paused = true, rtheta = true;
  reset_all(bomb_start_x, bomb_start_y, coin_speed+25, coin_angle_deg, bomb_ax, bomb_ay+10 , paused, rtheta);
}
void Coin::initCoin() {
  coin_start_x = (PLAY_X_START+WINDOW_X)/2;
  coin_start_y = PLAY_Y_HEIGHT;
  coin_circle.reset(coin_start_x, coin_start_y, COIN_SIZE);
  coin_circle.setColor(COLOR("red"));
  coin_circle.setFill(true);
  addPart(&coin_circle);
}

void Coin::resetCoin() {
  double coin_speed = COIN_SPEED;
  double coin_angle_deg = COIN_ANGLE_DEG;
  coin_ax = 0;
  coin_ay = COIN_G;
  bool paused = true, rtheta = true;
  reset_all(coin_start_x, coin_start_y, coin_speed, coin_angle_deg, coin_ax, coin_ay, paused, rtheta);
}
void BCoin::initBCoin() {
  bcoin_start_x = ((PLAY_X_START+WINDOW_X)/2)-50;
  bcoin_start_y = PLAY_Y_HEIGHT;
  bcoin_circle.reset(bcoin_start_x, bcoin_start_y, COIN_SIZE);
  bcoin_circle.setColor(COLOR("green"));
  bcoin_circle.setFill(true);
  addPart(&bcoin_circle);
}

void BCoin::resetBCoin() {
  double coin_speed = COIN_SPEED*1.1547;
  double coin_angle_deg = COIN_ANGLE_DEG-30;
  bcoin_ax = 0;
  bcoin_ay = COIN_G;
  bool paused = true, rtheta = true;
  reset_all(bcoin_start_x, bcoin_start_y, coin_speed, coin_angle_deg, bcoin_ax, bcoin_ay, paused, rtheta);
}
//lasso.cpp

void Lasso::draw_lasso_band() {
  double len = (release_speed/MAX_RELEASE_SPEED)*LASSO_BAND_LENGTH;
  double arad = release_angle_deg*PI/180.0;
  double xlen = len*cos(arad);
  double ylen = len*sin(arad);
  lasso_band.reset(lasso_start_x, lasso_start_y, (lasso_start_x-xlen), (lasso_start_y+ylen));
  lasso_band.setThickness(LASSO_THICKNESS);
} // End Lasso::draw_lasso_band()

void Lasso::initLasso() {
  lasso_start_x = (PLAY_X_START+LASSO_X_OFFSET);
  lasso_start_y = (PLAY_Y_HEIGHT-LASSO_Y_HEIGHT);
  lasso_circle.reset(lasso_start_x, lasso_start_y, LASSO_SIZE);
  lasso_circle.setColor(COLOR("yellow"));
  lasso_circle.setFill(true);
  lasso_loop.reset(lasso_start_x, lasso_start_y, LASSO_SIZE/2);
  lasso_loop.setColor(COLOR("brown"));
  lasso_loop.setFill(true);
  addPart(&lasso_circle);
  addPart(&lasso_loop);
  lasso_looped = false;
  the_coin = NULL;
  coin_count=0;
  num_coins = 0;
  coin_step=1;
  level=1;

  lasso_line.reset(lasso_start_x, lasso_start_y, lasso_start_x, lasso_start_y);
  lasso_line.setColor(COLOR("brown"));

  lasso_band.setColor(COLOR("blue"));
  draw_lasso_band();

} // End Lasso::initLasso()

void Lasso::yank() {
  bool paused = true, rtheta = true;
  reset_all(lasso_start_x, lasso_start_y, release_speed, release_angle_deg, lasso_ax, lasso_ay, paused, rtheta);
  lasso_loop.reset(lasso_start_x, lasso_start_y, LASSO_SIZE/2);
  lasso_loop.setFill(true);
  lasso_looped = false;
  coin_step++;
  if(coin_step>5){if(coin_count>=2){level++;coin_step=1;coin_count=0;
  if(level<4){
    string messeg("LEVEL CLEARED !");
  Text charPressed(PLAY_X_START+400, PLAY_Y_HEIGHT-400, messeg); wait(1);}}
                    else {coin_step=0;
                    string messeg("RETRY LEVEL !");
  Text charPressed(PLAY_X_START+400, PLAY_Y_HEIGHT-400, messeg); wait(1);}}

  if(the_coin != NULL) {
    the_coin->resetCoin();
  }
    /*if(the_bcoin != NULL) {
    the_bcoin->resetBCoin();}
    if(the_bomb != NULL) {
    the_bomb->resetBomb();}*/
} // End Lasso::yank()

void Lasso::loopit() {
  if(lasso_looped) { return; } // Already looped
  lasso_loop.reset(getXPos(), getYPos(), LASSO_RADIUS);
  lasso_loop.setFill(false);
  lasso_looped = true;
} // End Lasso::loopit()

void Lasso::addAngle(double angle_deg) {
  release_angle_deg += angle_deg;
  if(release_angle_deg < MIN_RELEASE_ANGLE_DEG) { release_angle_deg = MIN_RELEASE_ANGLE_DEG; }
  if(release_angle_deg > MAX_RELEASE_ANGLE_DEG) { release_angle_deg = MAX_RELEASE_ANGLE_DEG; }
  bool paused = true, rtheta = true;
  reset_all(lasso_start_x, lasso_start_y, release_speed, release_angle_deg, lasso_ax, lasso_ay, paused, rtheta);
} // End Lasso::addAngle()

void Lasso::addSpeed(double speed) {
  release_speed += speed;
  if(release_speed < MIN_RELEASE_SPEED) { release_speed = MIN_RELEASE_SPEED; }
  if(release_speed > MAX_RELEASE_SPEED) { release_speed = MAX_RELEASE_SPEED; }
  bool paused = true, rtheta = true;
  reset_all(lasso_start_x, lasso_start_y, release_speed, release_angle_deg, lasso_ax, lasso_ay, paused, rtheta);
} // End Lasso::addSpeed()

void Lasso::nextStep(double stepTime) {
  draw_lasso_band();
  MovingObject::nextStep(stepTime);
  if(getYPos() > PLAY_Y_HEIGHT) { yank(); }
  lasso_line.reset(lasso_start_x, lasso_start_y, getXPos(), getYPos());

} // End Lasso::nextStep()
void Lasso::check_for_bomb(Bomb *coinPtr) {
  double lasso_x = getXPos();
  double lasso_y = getYPos();
  double coin_x = coinPtr->getXPos();
  double coin_y = coinPtr->getYPos();
  double xdiff = (lasso_x - coin_x);
  double ydiff = (lasso_y - coin_y);
  double distance = sqrt((xdiff*xdiff)+(ydiff*ydiff));
  if(distance <= LASSO_RADIUS) {
    the_bomb = coinPtr;
    num_coins--;
    coin_count--;
    if (distance <=(1e-5)){num_coins++;
    coin_count++;}// this prevents multiple looping of coin
    else{
    the_bomb->getAttachedTo(this);
    string messeg("Oops caught a bomb :( ");
  Text charPressed(PLAY_X_START+400, PLAY_Y_HEIGHT-350, messeg); charPressed.setColor(COLOR("red"));wait(0.7);}
  }}
  void Lasso::check_for_bcoin(BCoin *coinPtr) {
  double lasso_x = getXPos();
  double lasso_y = getYPos();
  double coin_x = coinPtr->getXPos();
  double coin_y = coinPtr->getYPos();
  double xdiff = (lasso_x - coin_x);
  double ydiff = (lasso_y - coin_y);
  double distance = sqrt((xdiff*xdiff)+(ydiff*ydiff));
  if(distance <= LASSO_RADIUS) {
    the_bcoin = coinPtr;
    num_coins+=2;
    coin_count+=2;
    if (distance <=(1e-5)){num_coins-=2;
    coin_count-=2;}
    else{
    the_bcoin->getAttachedTo(this);
    string messeg("Yaay, caught a bonus coin !!");
  Text charPressed(PLAY_X_START+400, PLAY_Y_HEIGHT-350, messeg);charPressed.setColor(COLOR("green")); wait(0.7);}
  }}
void Lasso::check_for_coin(Coin *coinPtr) {
  double lasso_x = getXPos();
  double lasso_y = getYPos();
  double coin_x = coinPtr->getXPos();
  double coin_y = coinPtr->getYPos();
  double xdiff = (lasso_x - coin_x);
  double ydiff = (lasso_y - coin_y);
  double distance = sqrt((xdiff*xdiff)+(ydiff*ydiff));
  if(distance <= LASSO_RADIUS) {
    the_coin = coinPtr;
    num_coins++;
    coin_count++;
    if (distance <=(1e-5)){num_coins--;
    coin_count--;}// to prevent multiple looping on same coin
    else{
    the_coin->getAttachedTo(this);
    string messeg("Yaay caught a coin :)");
  Text charPressed(PLAY_X_START+400, PLAY_Y_HEIGHT-350, messeg);charPressed.setColor(COLOR("blue")); wait(0.7);}

  }
} // End Lasso::check_for_coin()


main_program {

  initCanvas("Lasso", WINDOW_X, WINDOW_Y);
  float stepTime = STEP_TIME;
  float runTime = -1; // sec; -ve means infinite
  float currTime = 0;
  help_page();
  double release_speed = INIT_RELEASE_SPEED; // m/s
  double release_angle_deg = INIT_RELEASE_ANGLE_DEG; // degrees
  double lasso_ax = 0;
  double lasso_ay = LASSO_G;
  bool paused = true;
  bool rtheta = true;
  Lasso lasso(release_speed, release_angle_deg, lasso_ax, lasso_ay, paused, rtheta);

  Line b1(0, PLAY_Y_HEIGHT, WINDOW_X, PLAY_Y_HEIGHT);
  b1.setColor(COLOR("blue"));
  Line b2(PLAY_X_START, 0, PLAY_X_START, WINDOW_Y);
  b2.setColor(COLOR("blue"));

  string msg("Cmd: _");
  Text charPressed(PLAY_X_START+50, PLAY_Y_HEIGHT+20, msg);
  char coinScoreStr[256];
  sprintf(coinScoreStr, " Total Coins: %d", lasso.getNumCoins());
  Text coinScore(PLAY_X_START+50, PLAY_Y_HEIGHT+50, coinScoreStr);
  char CoinStep[256];
  sprintf(CoinStep,"Attempts: %d",lasso.getCoinstep());
 Text coinst(PLAY_X_START+50, PLAY_Y_HEIGHT, CoinStep);
  char level[256];
  sprintf(level,"Level: %d",lasso.getlevel());
  Text mylevel(PLAY_X_START+50, PLAY_Y_HEIGHT-450, level);
  char levelscore[256];
  sprintf(levelscore,"Level Score: %d",lasso.getlevelscore());
   Text mylevelscore(PLAY_X_START+450, PLAY_Y_HEIGHT+20, level);

  paused = true; rtheta = true;
  double coin_speed = COIN_SPEED;
  double coin_angle_deg = COIN_ANGLE_DEG;
  double coin_ax = 0;
  double coin_ay = COIN_G;
  Coin coin(coin_speed, coin_angle_deg, coin_ax, coin_ay, paused, rtheta);

  // After every COIN_GAP sec, make the coin jump
  double last_coin_jump_end = 0;





  // When t is pressed, throw lasso
  // If lasso within range, make coin stick
  // When y is pressed, yank lasso
  // When l is pressed, loop lasso
  // When q is pressed, quit

  while(lasso.getlevel()==1) {
    if((runTime > 0) && (currTime > runTime)) { break; }

    XEvent e;
    bool pendingEv = checkEvent(e);
    if(pendingEv) {
      char c = charFromEvent(e);
      msg[msg.length()-1] = c;
      charPressed.setMessage(msg);
      switch(c) {
      case 't':
	lasso.unpause();
	break;
      case 'y':
	lasso.yank();
	break;
      case 'l':
	lasso.loopit();
	lasso.check_for_coin(&coin);
//	lasso.check_for_bcoin(&bcoin);
	//lasso.check_for_bomb(&bomb);
	wait(STEP_TIME*5);
	break;
      case '[':
	if(lasso.isPaused()) { lasso.addAngle(-RELEASE_ANGLE_STEP_DEG);	}
	break;
      case ']':
	if(lasso.isPaused()) { lasso.addAngle(+RELEASE_ANGLE_STEP_DEG); }
	break;
      case '-':
	if(lasso.isPaused()) { lasso.addSpeed(-RELEASE_SPEED_STEP); }
	break;
      case '=':
	if(lasso.isPaused()) { lasso.addSpeed(+RELEASE_SPEED_STEP); }
	break;
      case 'q':
	exit(0);
      default:
	break;
      }
    }

    lasso.nextStep(stepTime);

    coin.nextStep(stepTime);
    if(coin.isPaused()) {
      if((currTime-last_coin_jump_end) >= COIN_GAP) {
	coin.unpause();
      }
    }

    if(coin.getYPos() > PLAY_Y_HEIGHT) {
      coin.resetCoin();
      last_coin_jump_end = currTime;
    }
   /* bcoin.nextStep(stepTime);
    if(bcoin.isPaused()) {
      if((currTime-last_bcoin_jump_end) >= COIN_GAP) {
	bcoin.unpause();
      }
    }

    if(bcoin.getYPos() > PLAY_Y_HEIGHT) {
      bcoin.resetBCoin();
      last_bcoin_jump_end = currTime;
    }
    bomb.nextStep(stepTime);
    if(bomb.isPaused()) {
      if((currTime-last_bomb_jump_end) >= COIN_GAP) {
	bomb.unpause();
	//coinStep++;
      }
    }

    if(bomb.getYPos() > PLAY_Y_HEIGHT) {
      bomb.resetBomb();
     // coinStep++;
      last_bomb_jump_end = currTime;
    }*/

    sprintf(coinScoreStr, "Total Coins: %d", lasso.getNumCoins());
    coinScore.setMessage(coinScoreStr);
      if(lasso.getlevelscore()<0)
    {string messeg("OnO Defeated");
  Text charPressed(PLAY_X_START+100, PLAY_Y_HEIGHT-400, messeg);
  wait(5); exit(0);}

    sprintf(CoinStep,"Attempts: %d",lasso.getCoinstep());
    coinst.setMessage(CoinStep);

  sprintf(levelscore,"Level Score: %d",lasso.getlevelscore());
  mylevelscore.setMessage(levelscore);

  sprintf(level,"Level: %d",lasso.getlevel());
  mylevel.setMessage(level);

    currTime += stepTime;
    wait(stepTime);
  } // End for(;;)
while(lasso.getlevel()>1)  {
Bomb bomb(coin_speed+25, coin_angle_deg, coin_ax, coin_ay+10, paused, rtheta);
  double last_bomb_jump_end = 0;
  while(lasso.getlevel()==2) {
    if((runTime > 0) && (currTime > runTime)) { break; }

    XEvent e;
    bool pendingEv = checkEvent(e);
    if(pendingEv) {
      char c = charFromEvent(e);
      msg[msg.length()-1] = c;
      charPressed.setMessage(msg);
      switch(c) {
      case 't':
	lasso.unpause();
	break;
      case 'y':
	lasso.yank();
	break;
      case 'l':
	lasso.loopit();
	lasso.check_for_coin(&coin);
	lasso.check_for_bomb(&bomb);
	wait(STEP_TIME*5);
	break;
      case '[':
	if(lasso.isPaused()) { lasso.addAngle(-RELEASE_ANGLE_STEP_DEG);	}
	break;
      case ']':
	if(lasso.isPaused()) { lasso.addAngle(+RELEASE_ANGLE_STEP_DEG); }
	break;
      case '-':
	if(lasso.isPaused()) { lasso.addSpeed(-RELEASE_SPEED_STEP); }
	break;
      case '=':
	if(lasso.isPaused()) { lasso.addSpeed(+RELEASE_SPEED_STEP); }
	break;
      case 'q':
	exit(0);
      default:
	break;
      }
    }

    lasso.nextStep(stepTime);

    coin.nextStep(stepTime);
    if(coin.isPaused()) {
      if((currTime-last_coin_jump_end) >= COIN_GAP) {
	coin.unpause();
      }
    }

    if(coin.getYPos() > PLAY_Y_HEIGHT) {
      coin.resetCoin();
      last_coin_jump_end = currTime;
    }
    bomb.nextStep(stepTime);
    if(bomb.isPaused()) {
      if((currTime-last_bomb_jump_end) >= COIN_GAP) {
	bomb.unpause();
      }
    }

    if(bomb.getYPos() > PLAY_Y_HEIGHT) {
      bomb.resetBomb();
      last_bomb_jump_end = currTime;
    }

    sprintf(coinScoreStr, "Total Coins: %d", lasso.getNumCoins());
    coinScore.setMessage(coinScoreStr);
      if(lasso.getlevelscore()<0)
    {string messeg("OnO Defeated");
  Text charPressed(PLAY_X_START+300, PLAY_Y_HEIGHT-400, messeg);
  wait(5); exit(0);}

    sprintf(CoinStep,"Attempts: %d",lasso.getCoinstep());
    coinst.setMessage(CoinStep);

 sprintf(levelscore,"Level Score: %d",lasso.getlevelscore());
  mylevelscore.setMessage(levelscore);

  sprintf(level,"Level: %d",lasso.getlevel());
  mylevel.setMessage(level);

    currTime += stepTime;
    wait(stepTime);
  } // End for(;;)
while(lasso.getlevel()>2)  {
     BCoin bcoin(coin_speed*1.1547, coin_angle_deg-30, coin_ax, coin_ay, paused, rtheta);
     double last_bcoin_jump_end = 0;
     while(lasso.getlevel()>2)  {if((runTime > 0) && (currTime > runTime)) { break; }

    XEvent e;
    bool pendingEv = checkEvent(e);
    if(pendingEv) {
      char c = charFromEvent(e);
      msg[msg.length()-1] = c;
      charPressed.setMessage(msg);
      switch(c) {
      case 't':
	lasso.unpause();
	break;
      case 'y':
	lasso.yank();
	break;
      case 'l':
	lasso.loopit();
	lasso.check_for_coin(&coin);
	lasso.check_for_bcoin(&bcoin);
	lasso.check_for_bomb(&bomb);
	wait(STEP_TIME*5);
	break;
      case '[':
	if(lasso.isPaused()) { lasso.addAngle(-RELEASE_ANGLE_STEP_DEG);	}
	break;
      case ']':
	if(lasso.isPaused()) { lasso.addAngle(+RELEASE_ANGLE_STEP_DEG); }
	break;
      case '-':
	if(lasso.isPaused()) { lasso.addSpeed(-RELEASE_SPEED_STEP); }
	break;
      case '=':
	if(lasso.isPaused()) { lasso.addSpeed(+RELEASE_SPEED_STEP); }
	break;
      case 'q':
	exit(0);
      default:
	break;
      }
    }

    lasso.nextStep(stepTime);

    coin.nextStep(stepTime);
    if(coin.isPaused()) {
      if((currTime-last_coin_jump_end) >= COIN_GAP) {
	coin.unpause();
      }
    }

    if(coin.getYPos() > PLAY_Y_HEIGHT) {
      coin.resetCoin();
      last_coin_jump_end = currTime;
    }
    bcoin.nextStep(stepTime);
    if(bcoin.isPaused()) {
      if((currTime-last_bcoin_jump_end) >= COIN_GAP) {
	bcoin.unpause();
      }
    }

    if(bcoin.getYPos() > PLAY_Y_HEIGHT) {
      bcoin.resetBCoin();
      last_bcoin_jump_end = currTime;
    }
    bomb.nextStep(stepTime);
    if(bomb.isPaused()) {
      if((currTime-last_bomb_jump_end) >= COIN_GAP) {
	bomb.unpause();
      }
    }

    if(bomb.getYPos() > PLAY_Y_HEIGHT) {
      bomb.resetBomb();
      last_bomb_jump_end = currTime;
    }

    sprintf(coinScoreStr, "Total Coins: %d", lasso.getNumCoins());
    coinScore.setMessage(coinScoreStr);
      if(lasso.getlevelscore()<0)
    {string messeg("OnO Defeated");
  Text charPressed(PLAY_X_START+300, PLAY_Y_HEIGHT-400, messeg);
  wait(5); exit(0);}
 if(lasso.getlevel()>3)
    {string messeg("Woohoo Game Completed");
  Text charPressed(PLAY_X_START+300, PLAY_Y_HEIGHT-350, messeg);
  wait(5); exit(0);}

    sprintf(CoinStep,"Attempts: %d",lasso.getCoinstep());
    coinst.setMessage(CoinStep);


 sprintf(levelscore,"Level Score: %d",lasso.getlevelscore());
  mylevelscore.setMessage(levelscore);

  sprintf(level,"Level: %d",lasso.getlevel());
  mylevel.setMessage(level);

    currTime += stepTime;
    wait(stepTime);}
}}
  wait(3);
} // End main_program
